<?php
/**
 * Thankyou page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/thankyou.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.7.0
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="woocommerce-order">

	<?php
	if ( $order ) :

		do_action( 'woocommerce_before_thankyou', $order->get_id() );
		?>

		<?php if ( $order->has_status( 'failed' ) ) : ?>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed"><?php esc_html_e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woocommerce' ); ?></p>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
				<a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="button pay"><?php esc_html_e( 'Pay', 'woocommerce' ); ?></a>
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button pay"><?php esc_html_e( 'My account', 'woocommerce' ); ?></a>
				<?php endif; ?>
			</p>

		<?php else : ?>

			<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', esc_html__( 'Thank you. Your order has been received.', 'woocommerce' ), $order ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>

			<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">

				<li class="woocommerce-order-overview__order order">
					<?php esc_html_e( 'Order number:', 'woocommerce' ); ?>
					<strong><?php echo $order->get_order_number(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
				</li>

				<li class="woocommerce-order-overview__date date">
					<?php esc_html_e( 'Date:', 'woocommerce' ); ?>
					<strong><?php echo wc_format_datetime( $order->get_date_created() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
				</li>

				<?php if ( is_user_logged_in() && $order->get_user_id() === get_current_user_id() && $order->get_billing_email() ) : ?>
					<li class="woocommerce-order-overview__email email">
						<?php esc_html_e( 'Email:', 'woocommerce' ); ?>
						<strong><?php echo $order->get_billing_email(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
					</li>
				<?php endif; ?>

				<li class="woocommerce-order-overview__total total">
					<?php esc_html_e( 'Total:', 'woocommerce' ); ?>
					<strong><?php echo $order->get_formatted_order_total(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong>
				</li>

				<?php if ( $order->get_payment_method_title() ) : ?>
					<li class="woocommerce-order-overview__payment-method method">
						<?php esc_html_e( 'Payment method:', 'woocommerce' ); ?>
						<strong><?php echo wp_kses_post( $order->get_payment_method_title() ); ?></strong>
					</li>
				<?php endif; ?>

			</ul>

		<?php endif; ?>

		<?php do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id() ); ?>
		<?php do_action( 'woocommerce_thankyou', $order->get_id() ); ?>

	<?php else : ?>

		<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', esc_html__( 'Thank you. Your order has been received.', 'woocommerce' ), null ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>

	<?php endif; ?>

</div>

<?php if ( $order->has_status( 'failed' ) ){?>

<?php } else {?>

<?php
date_default_timezone_set('Asia/Kolkata');

 $vendor_cutoff_datetime_new2=array();
 
 	foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			$_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
            
    $post_obj    = get_post( $cart_item['product_id'] ); // The WP_Post object
    $post_author = $post_obj->post_author; // <=== The post author ID
    
    $vendor_cutoff_datetime = get_user_meta( $post_author, 'cutoff_datetime', true ); 
    
    $cutoff_day = get_user_meta( $post_author, 'cutoff_day', true );        
    $cutoff_time = get_user_meta( $post_author, 'cutoff_time', true ); 
    
    $cutoff_day_new = date( 'd/m/Y', strtotime( $cutoff_day.' this week' ) );	
    $cutoff_day_new2 = $cutoff_day_new.' '.$cutoff_time;
		
	$cutoff_day_new_t = date( 'm/d/Y', strtotime( $cutoff_day.' this week' ) );	
    $cutoff_day_new2_t = $cutoff_day_new_t.' '.$cutoff_time;	
   
   $vendor_cutoff_datetime_new = strtotime($cutoff_day_new2_t);
   $vendor_cutoff_datetime_new2[] = $vendor_cutoff_datetime_new;
   
   }
   
   //print_r($vendor_cutoff_datetime_new2);

$smallest= min($vendor_cutoff_datetime_new2);


$date_current = strtotime(date('m/d/Y H:i'));

if($smallest>$date_current){
$saturday = date( 'd/m/Y', strtotime( 'saturday this week' ) );

 $saturday_new = date( 'F j, Y', strtotime( 'saturday this week' ) );
 $sunday = date('F j, Y', strtotime($saturday_new. ' + 1 day'));
 $monday = date('F j, Y', strtotime($saturday_new. ' + 2 days'));
	
 $saturday_new2 = date( 'l j F', strtotime( 'saturday this week' ) );
 $sunday2 = date('l j F', strtotime($saturday_new2. ' + 1 day'));
 $monday2 = date('l j F', strtotime($saturday_new2. ' + 2 days'));	
?>

<!--<p>Your order will be delivered on Saturday (<?php //echo $saturday;?>)</p>-->

<?php } else {
$saturday = date( 'd/m/Y', strtotime( 'saturday next week' ) );

 $saturday_new = date( 'F j, Y', strtotime( 'saturday next week' ) );
 $sunday = date('F j, Y', strtotime($saturday_new. ' + 1 day'));
 $monday = date('F j, Y', strtotime($saturday_new. ' + 2 days'));
	
	
 $saturday_new2 = date( 'l j F', strtotime( 'saturday next week' ) );
 $sunday2 = date('l j F', strtotime($saturday_new2. ' + 1 day'));
 $monday2 = date('l j F', strtotime($saturday_new2. ' + 2 days'));	
	

?>
<!--<p>Your order will be delivered on Saturday (<?php //echo $saturday;?>)</p>-->

<?php } ?>

<?php
// Start the session
//session_start();
  
// Get session variables
 /*$saturday_new2 = $_SESSION["saturday_new2"];  
 $sunday2 = $_SESSION["sunday2"];
 $monday2 = $_SESSION["monday2"];*/ 

$checkout_page_after_select_collection_show_text = get_field('checkout_page_after_select_collection_show_text', 1859);
$checkout_page_after_select_collection_show_time1 = get_field('checkout_page_after_select_collection_show_time1', 1859);
$checkout_page_after_select_collection_show_time2 = get_field('checkout_page_after_select_collection_show_time2', 1859);
$checkout_page_after_select_collection_show_time3 = get_field('checkout_page_after_select_collection_show_time3', 1859);
$collection_address = get_field('collection_address', 1859);

?>

<script>
jQuery(document).ready(function($){	

var shipping_opt = localStorage.getItem("shipping_opt");
var zip_code_opt = localStorage.getItem("zip_code_opt");	
	
if(shipping_opt=='collection'){
	
<?php
$user_id = get_current_user_ID();

$user_info = get_userdata($user_id);
$username = $user_info->user_login;
$first_name = $user_info->first_name;
$last_name = $user_info->last_name;
$user_name = $user_info->display_name;
$user_email = $user_info->user_email;


/* user email notofication starts */
        
        $subject = 'Putneyshop - Order Collection Information';
		$to = $user_email;
		$from = get_option( 'admin_email' );
		
		$headers[] = 'From: Putneyshop <' . trim($from) . '>';
		$headers[] = 'Reply-To: <' . trim($from) . '>';
		$headers[] = 'Content-Type: text/html; charset=UTF-8';

			$html_body_student = '<html><body>
                  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate;mso-table-lspace: 0pt;mso-table-rspace: 0pt;width: 100%;">
                    <tr>
                      <td style="font-family: \'Imprima\', sans-serif;font-size: 14px !important;vertical-align: top;">

                        <p style="margin-bottom: 10px;">Hi '.$first_name.',</p>
						
				<p class="" style="margin-bottom: 10px;">				
				Order number: <strong>'.$order->get_order_number().'</strong><br>				
				Date: <strong>'.wc_format_datetime( $order->get_date_created() ).'</strong>				
				</p>
						

                  <p style="min-height:75px;font-family: \'Imprima\', \'Imprima\', sans-serif;font-size: 14px !important;font-weight: normal;margin: 0;margin-bottom: 15px;">
			
				'.$checkout_page_after_select_collection_show_text.'
				<br>
				'.$saturday_new2.': '.$checkout_page_after_select_collection_show_time1.'<br>
				'.$sunday2.': '.$checkout_page_after_select_collection_show_time2.'<br>
				'.$monday2.': '.$checkout_page_after_select_collection_show_time3.'
				<br><br>
				'.$collection_address.'
				
			</p>

   
                     
                      </td>
                    </tr>
                  </table>

            <!-- START FOOTER -->
            <div class="footer" style="clear: both;padding-top: 10px;width: 100%;">
              <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate;mso-table-lspace: 0pt;mso-table-rspace: 0pt;width: 100%;">
                <tr>
                  <td class="content-block" style="font-family: \'Imprima\', sans-serif;font-size: 16px !important;vertical-align: top;color: #999999;">
                    <p style="margin-bottom: 10px;"><hr/></p>
                    <span class="apple-link" style="color: #999999;font-size: 12px !important;">This e-mail was sent from a booking form on Putneyshop</span>
                  </td>
                </tr>
              </table>
            </div>
          </body></html>';

		
		wp_mail($to, $subject, $html_body_student, $headers); 
		
		$html_body_tutor = '<html><body>
                  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate;mso-table-lspace: 0pt;mso-table-rspace: 0pt;width: 100%;">
                    <tr>
                      <td style="font-family: \'Imprima\', sans-serif;font-size: 14px !important;vertical-align: top;">

                        <p style="margin-bottom: 10px;">Hello Admin,</p>
						
				<p class="" style="margin-bottom: 10px;">				
				Order number: <strong>'.$order->get_order_number().'</strong><br>				
				Date: <strong>'.wc_format_datetime( $order->get_date_created() ).'</strong>				
				</p>

         <p style="min-height:75px;font-family: \'Imprima\', \'Imprima\', sans-serif;font-size: 14px !important;font-weight: normal;margin: 0;margin-bottom: 15px;">
			
				'.$checkout_page_after_select_collection_show_text.'
				<br>
				'.$saturday_new2.': '.$checkout_page_after_select_collection_show_time1.'<br>
				'.$sunday2.': '.$checkout_page_after_select_collection_show_time2.'<br>
				'.$monday2.': '.$checkout_page_after_select_collection_show_time3.'
				<br><br>
				'.$collection_address.'
				
			</p>


                     
                      </td>
                    </tr>
                  </table>

            <!-- START FOOTER -->
            <div class="footer" style="clear: both;padding-top: 10px;width: 100%;">
              <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate;mso-table-lspace: 0pt;mso-table-rspace: 0pt;width: 100%;">
                <tr>
                  <td class="content-block" style="font-family: \'Imprima\', sans-serif;font-size: 16px !important;vertical-align: top;color: #999999;">
                    <p style="margin-bottom: 10px;"><hr/></p>
                    <span class="apple-link" style="color: #999999;font-size: 12px !important;">This e-mail was sent from a booking form on Putneyshop</span>
                  </td>
                </tr>
              </table>
            </div>
          </body></html>';

        wp_mail($from, $subject, $html_body_tutor, $headers); 
?>	

}else{

}

});	
</script>

<?php } ?>

