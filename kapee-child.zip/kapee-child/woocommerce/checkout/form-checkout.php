<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}

?>
<?php
date_default_timezone_set('Asia/Kolkata');

 $vendor_cutoff_datetime_new2=array();
 
 	foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			$_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
            
    $post_obj    = get_post( $cart_item['product_id'] ); // The WP_Post object
    $post_author = $post_obj->post_author; // <=== The post author ID
    
    $vendor_cutoff_datetime = get_user_meta( $post_author, 'cutoff_datetime', true ); 
    
    $cutoff_day = get_user_meta( $post_author, 'cutoff_day', true );        
    $cutoff_time = get_user_meta( $post_author, 'cutoff_time', true ); 
    
    $cutoff_day_new = date( 'd/m/Y', strtotime( $cutoff_day.' this week' ) );	
    $cutoff_day_new2 = $cutoff_day_new.' '.$cutoff_time;
		
	$cutoff_day_new_t = date( 'm/d/Y', strtotime( $cutoff_day.' this week' ) );	
    $cutoff_day_new2_t = $cutoff_day_new_t.' '.$cutoff_time;	
   
   $vendor_cutoff_datetime_new = strtotime($cutoff_day_new2_t);
   $vendor_cutoff_datetime_new2[] = $vendor_cutoff_datetime_new;
   
   }
   
   //print_r($vendor_cutoff_datetime_new2);

$smallest= min($vendor_cutoff_datetime_new2);


$date_current = strtotime(date('m/d/Y H:i'));

if($smallest>$date_current){
$saturday = date( 'd/m/Y', strtotime( 'saturday this week' ) );

 $saturday_new = date( 'F j, Y', strtotime( 'saturday this week' ) );
 $sunday = date('F j, Y', strtotime($saturday_new. ' + 1 day'));
 $monday = date('F j, Y', strtotime($saturday_new. ' + 2 days'));
	
 $saturday_new2 = date( 'l j F', strtotime( 'saturday this week' ) );
 $sunday2 = date('l j F', strtotime($saturday_new2. ' + 1 day'));
 $monday2 = date('l j F', strtotime($saturday_new2. ' + 2 days'));	
?>

<!--<p>Your order will be delivered on Saturday (<?php //echo $saturday;?>)</p>-->

<?php } else {
$saturday = date( 'd/m/Y', strtotime( 'saturday next week' ) );

 $saturday_new = date( 'F j, Y', strtotime( 'saturday next week' ) );
 $sunday = date('F j, Y', strtotime($saturday_new. ' + 1 day'));
 $monday = date('F j, Y', strtotime($saturday_new. ' + 2 days'));
	
	
 $saturday_new2 = date( 'l j F', strtotime( 'saturday next week' ) );
 $sunday2 = date('l j F', strtotime($saturday_new2. ' + 1 day'));
 $monday2 = date('l j F', strtotime($saturday_new2. ' + 2 days'));	
	

?>
<!--<p>Your order will be delivered on Saturday (<?php //echo $saturday;?>)</p>-->

<?php } ?>

<?php
// Start the session
//session_start();
	
// Set session variables
/*$_SESSION["saturday_new2"] = $saturday_new2;
$_SESSION["sunday2"] = $sunday2;	
$_SESSION["monday2"] = $monday2;*/	
?>

<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

	<?php if ( $checkout->get_checkout_fields() ) : ?>

		<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

		<div class="col2-set" id="customer_details">
			<div class="col-1">
				<?php do_action( 'woocommerce_checkout_billing' ); ?>
			
			
			<p class="cus_coltxt_chkout" style="display:none;">
				<?php echo get_field('checkout_page_after_select_collection_show_text', 1859);?>
				<br>
				<?php echo $saturday_new2;?>: <?php echo get_field('checkout_page_after_select_collection_show_time1', 1859);?><br>
				<?php echo $sunday2;?>: <?php echo get_field('checkout_page_after_select_collection_show_time2', 1859);?><br>
				<?php echo $monday2;?>: <?php echo get_field('checkout_page_after_select_collection_show_time3', 1859);?>
				<br><br>
				<?php echo get_field('collection_address', 1859);?>
				
			</p>
</div>
			<div class="col-2">
				<?php do_action( 'woocommerce_checkout_shipping' ); ?>
			</div>
		</div>

		<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

	<?php endif; ?>
	
	<div id="cus_order_content">
	<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
	
	<h3 id="order_review_heading"><?php esc_html_e( 'Your order', 'woocommerce' ); ?></h3>
	
	<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

	<div id="order_review" class="woocommerce-checkout-review-order">
		<?php do_action( 'woocommerce_checkout_order_review' ); ?>
	</div>

	<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
	</div>	

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>

<?php 
if($post_author==1){
?>
<style>
#coderockz_woo_delivery_setting_wrapper_internal {
display:none;
}
</style>

<script>
jQuery(document).ready(function($){

$('#coderockz_woo_delivery_delivery_selection_box').val('');
$('#coderockz_woo_delivery_delivery_selection_box').prop('required',false);
	
$('#coderockz_woo_delivery_date_datepicker').val('');
$('#coderockz_woo_delivery_date_datepicker').prop('required',false);

$('#coderockz_woo_delivery_time_field').val('');
$('#coderockz_woo_delivery_time_field').prop('required',false);

$('#coderockz_woo_delivery_pickup_date_datepicker').val('');
$('#coderockz_woo_delivery_pickup_date_datepicker').prop('required',false);

$('#coderockz_woo_delivery_pickup_time_field').val('');
$('#coderockz_woo_delivery_pickup_time_field').prop('required',false);	


});
</script>

<?php } else { ?>

<script>
jQuery(document).ready(function($){
setTimeout(function(){
	//$('#coderockz_woo_delivery_date_datepicker').val('<?php //echo $saturday;?>');
 }, 4000);
});
</script>

<script>
jQuery(document).ready(function($){	
setTimeout(function(){	
$('.flatpickr-day').addClass( 'flatpickr-disabled' );	

$(".flatpickr-rContainer").find("span[ aria-label='<?php echo $saturday_new;?>' ]").removeClass( 'flatpickr-disabled' );

$(".flatpickr-rContainer").find("span[ aria-label='<?php echo $sunday;?>' ]").removeClass( 'flatpickr-disabled' );

$(".flatpickr-rContainer").find("span[ aria-label='<?php echo $monday;?>' ]").removeClass( 'flatpickr-disabled' );

//$( '.flatpickr-rContainer span[ aria-label=April 10, 2021 ]' ).removeClass( 'flatpickr-disabled' );
}, 3000);	

	jQuery(document).on('click', '.flatpickr-calendar', function(e){
	e.preventDefault();	
	$('.flatpickr-day').addClass( 'flatpickr-disabled' );	
$(".flatpickr-rContainer").find("span[ aria-label='<?php echo $saturday_new;?>' ]").removeClass( 'flatpickr-disabled' );

$(".flatpickr-rContainer").find("span[ aria-label='<?php echo $sunday;?>' ]").removeClass( 'flatpickr-disabled' );

$(".flatpickr-rContainer").find("span[ aria-label='<?php echo $monday;?>' ]").removeClass( 'flatpickr-disabled' );
	});
	
	jQuery(document).on('change', '#coderockz_woo_delivery_date_datepicker', function(e){
	e.preventDefault();	

	$('.flatpickr-calendar').trigger( 'click' );
	
	});
	
	
	jQuery(document).on('click', '#coderockz_woo_delivery_pickup_date_datepicker', function(e){
	e.preventDefault();	

	$('.flatpickr-calendar').trigger( 'click' );
	
	});
	
	jQuery(document).on('change', '#coderockz_woo_delivery_delivery_selection_box', function(e){
	e.preventDefault();	
		
	var del_bx = $('#coderockz_woo_delivery_delivery_selection_box option:selected').val();	
    console.log(del_bx);	
		
	setTimeout(function(){		
	$('.flatpickr-calendar').trigger( 'click' );
		
	 if(del_bx=='pickup'){
	   $('#shipping_method li').hide();
	   $('#shipping_method li:last-child').show();			
	   $('.cus_coltxt_chkout').show();	
		 
	    $('.woocommerce-shipping-totals .shipping-title').html('Shipping: ');
	    $('.woocommerce-shipping-totals.shipping th').html('Shipping: ');
		 
		 $('#billing_postcode_field input').attr('id','');
		 $('#shipping_postcode_field input').attr('id','');
		 $('.err_msg').hide();
		 
	localStorage.clear();
    localStorage.setItem("shipping_opt", "collection");	 
			
	   }else{
		 $('#shipping_method li').show();  
		 $('#shipping_method li:last-child').hide();
		 $('.cus_coltxt_chkout').hide();
		   
		
	    $('.woocommerce-shipping-totals .shipping-title').html('Shipping: ');
	    $('.woocommerce-shipping-totals.shipping th').html('Shipping: ');	
		   
		 $('#billing_postcode_field input').attr('id','billing_postcode');
		 $('#shipping_postcode_field input').attr('id','shipping_postcode');
		 $('.err_msg').show();  
 
		   
	localStorage.clear();
    localStorage.setItem("shipping_opt", "delivery");	   
	   }	
		
	}, 3000);
		
	});
	
	
	
});	
</script>




<?php } ?>

<script>
jQuery(document).ready(function($){	

var shipping_opt = localStorage.getItem("shipping_opt");
var zip_code_opt = localStorage.getItem("zip_code_opt");	
	
if(shipping_opt=='collection'){
		 $('#billing_postcode_field input').attr('id','');
		 $('#shipping_postcode_field input').attr('id','');  
	     $('.err_msg').hide();
}else{
		 $('#billing_postcode_field input').attr('id','billing_postcode');
		 $('#shipping_postcode_field input').attr('id','shipping_postcode');
	     $('.err_msg').show(); 
}

});	
</script>
