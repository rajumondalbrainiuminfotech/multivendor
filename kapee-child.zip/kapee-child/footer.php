<?php
/**
 * The template for displaying the footer
 *
 * @author 	PressLayouts
 * @package kapee
 * @since 1.0.0
 */
?>

<?php

$link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

$link_array = explode('/',$link);
$page = basename($link);


$args = array(
    'role'    => 'seller',
    'orderby' => 'user_nicename',
    'order'   => 'ASC'
);
$users = get_users( $args );

foreach ( $users as $user ) {
$the_user_id = $user->ID;
$dokan_store_name2 = $user->dokan_store_name;	

$zname_clean = strtolower(str_replace(" ", "-",$dokan_store_name2));
	

$dokan_store_name = $zname_clean;
	
if ($page == $dokan_store_name){
$the_user_id = $user->ID;
$dokan_store_name_new = $user->dokan_store_name;	
$vendor_description = str_replace("'", "",get_user_meta( $the_user_id, 'vendor_description', true ));	
	
$cutoff_day_ven = get_user_meta( $the_user_id, 'cutoff_day', true ); 
$cutoff_time_ven = get_user_meta( $the_user_id, 'cutoff_time', true ); 	
	
}
	
}


?>

<?php
$vendor_id = get_current_user_id();
$vendor_cutoff_datetime = get_user_meta( $vendor_id, 'cutoff_datetime', true ); 

$cutoff_day = get_user_meta( $vendor_id, 'cutoff_day', true ); 
$cutoff_time = get_user_meta( $vendor_id, 'cutoff_time', true ); 
 
if(isset($_REQUEST['cutoff_date_subm']))
{
		
//$cutoffdatetime=$_REQUEST['cutoffdatetime'];

$cutoff_day = $_REQUEST['cutoff_day'];
$cutoff_time = $_REQUEST['cutoff_time'];
	
$cutoff_day_new = date( 'd/m/Y', strtotime( $cutoff_day.' this week' ) );	
$cutoff_day_new2 = $cutoff_day_new.' '.$cutoff_time;
	
update_user_meta( $vendor_id, 'cutoff_datetime', $cutoff_day_new2 ); 
update_user_meta( $vendor_id, 'cutoff_day', $cutoff_day );
update_user_meta( $vendor_id, 'cutoff_time', $cutoff_time ); 	

$vendor_cutoff_datetime = get_user_meta( $vendor_id, 'cutoff_datetime', true );
	
$cutoff_day = get_user_meta( $vendor_id, 'cutoff_day', true ); 
$cutoff_time = get_user_meta( $vendor_id, 'cutoff_time', true ); 	
?>

<script>
jQuery(document).ready(function($){
    
    $('.dokan-dashboard-menu li').removeClass('active');
    $('.support_new').addClass('active');
    
    $('.dokan-dashboard-content header').hide();
    $('.dokan-dashboard-content article').hide();
    $('.dokan-dashboard-content table').hide();
    $('.dokan-dashboard-content ul').hide();
    $('.dokan-dashboard-content .dokan-info').hide();
    $('.dokan-subscription-content').hide();
    
    $('.dashboard-content-area').hide();
    
    
    
      $('.dokan-dashboard-content').append('<div class="cus_cutoffdate"><form method="post"><h3>Set Cut-off Date/Time<h3><hr><!--<input name="cutoffdatetime" id="datetimepicker" type="text" placeholder="d/m/Y H:i" value="<?php echo $vendor_cutoff_datetime;?>">--><?php $days = array("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday");?><select name="cutoff_day"><option>- Day -</option><?php foreach ($days as $value) { ?><option value="<?php echo $value;?>" <?php if($cutoff_day==$value){?>selected<?php } ?>><?php echo $value;?></option><?php }?></select><?php $times = array("12:00 AM", "1:00 AM", "2:00 AM", "3:00 AM", "4:00 AM", "5:00 AM", "6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM", "10:00 PM", "11:00 PM");?><select name="cutoff_time"><option>- Time -</option><?php foreach ($times as $value) { ?><option value="<?php echo $value;?>" <?php if($cutoff_time==$value){?>selected<?php } ?>><?php echo $value;?></option><?php }?></select><br><input type="submit" name="cutoff_date_subm" id="cutoff_date_subm" value="Set"></form><br><p>Your cut-off date/time is <b><?php echo $cutoff_day.' '.$cutoff_time;?></b> in every week.</p><p><i>*** you can reset it at any time</i></p></div>');
    
    
        setTimeout(function(){
        //$.datetimepicker.setLocale('pt-BR');
       	//$('#datetimepicker').datetimepicker();
		$("#datetimepicker").datetimepicker({
        format: "d/m/Y H:i"
       });
			
      }, 3000);
    

});
</script>

<?php
        
}

?>


<?php
// PHP program to add days to $Date
  
$Date = "2021/03/25 19:00";
  
// Add days to date and display it
//echo date('Y/m/d H:i', strtotime($Date. ' + 7 days'));
?>

<?php
date_default_timezone_set('Asia/Kolkata');
$date_current = strtotime(date('d/m/Y H:i'));

$args1 = array(
 'role' => 'seller',
 'orderby' => 'user_nicename',
 'order' => 'ASC'
);
 $subscribers = get_users($args1);
echo '<ul>';
 foreach ($subscribers as $user) {
 $user_id = $user->ID;
 $vendor_cutoff_datetime = get_user_meta( $user_id, 'cutoff_datetime', true ); 
 }
echo '</ul>';
?>

				</div><!-- .row -->		
			</div><!-- .container -->
			
			<?php do_action( 'kapee_site_content_botton' ); ?>
			
		</div><!-- .site-content -->
		
		<?php
		/**
		 * Hook: kapee_footer.
		 *
		 * @hooked kapee_template_footer- 10
		 */
		do_action( 'kapee_footer' );
		?>
		
	</div><!-- .site-wrapper -->
	
	<?php do_action( 'kapee_body_bottom' ); ?>
	<?php wp_footer(); ?>

<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.4/jquery.datetimepicker.min.css" />


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.4/build/jquery.datetimepicker.full.min.js"></script>-->


<script>
jQuery(document).ready(function($){
    
    $('<li class="support_new"><a href="javascript:void(0);"><i class="fa fa-calendar"></i> Cut-off Date/Time</a></li>').insertAfter('.dokan-dashboard-menu li.support');
    
    jQuery(document).on('click', '.support_new a', function(){
    
    //location.replace("/dashboard/");
    $('.dokan-dashboard-menu li').removeClass('active');
    $(this).parent().addClass('active');
    
    $('.dokan-dashboard-content header').hide();
    $('.dokan-dashboard-content article').hide();
    $('.dokan-dashboard-content table').hide();
    $('.dokan-dashboard-content ul').hide();
    $('.dokan-dashboard-content .dokan-info').hide();
    $('.dokan-subscription-content').hide();
    
    $('.dashboard-content-area').hide();
    
   $('.dokan-dashboard-content').append('<div class="cus_cutoffdate"><form method="post"><h3>Set Cut-off Date/Time<h3><hr><!--<input name="cutoffdatetime" id="datetimepicker" type="text" placeholder="d/m/Y H:i" value="<?php echo $vendor_cutoff_datetime;?>">--><?php $days = array("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday");?><select name="cutoff_day"><option>- Day -</option><?php foreach ($days as $value) { ?><option value="<?php echo $value;?>" <?php if($cutoff_day==$value){?>selected<?php } ?>><?php echo $value;?></option><?php }?></select><?php $times = array("12:00 AM", "1:00 AM", "2:00 AM", "3:00 AM", "4:00 AM", "5:00 AM", "6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM", "10:00 PM", "11:00 PM");?><select name="cutoff_time"><option>- Time -</option><?php foreach ($times as $value) { ?><option value="<?php echo $value;?>" <?php if($cutoff_time==$value){?>selected<?php } ?>><?php echo $value;?></option><?php }?></select><br><input type="submit" name="cutoff_date_subm" id="cutoff_date_subm" value="Set"></form><br><p>Your cut-off date/time is <b><?php echo $cutoff_day.' '.$cutoff_time;?></b> in every week.</p><p><i>*** you can reset it at any time</i></p></div>');
    
    
        setTimeout(function(){
        //$.datetimepicker.setLocale('pt-BR');
       	//$('#datetimepicker').datetimepicker();
		$("#datetimepicker").datetimepicker({
        format: "d/m/Y H:i"
       });	
      }, 3000);
    
    });

});
</script>

<script>
jQuery(document).ready(function($){
$('a.add_to_cart_button').attr('href','javascript:void(0)');
$('a.add_to_cart_button').removeClass('ajax_add_to_cart');	
jQuery(document).on('click', 'a.add_to_cart_button', function(e){	
e.preventDefault();	
var data_title = $(this).attr('aria-label');

var data_title_str = data_title.replace(/\s+/g, '-').toLowerCase();
var res = data_title_str.replace('add-“', '');
var res2 = res.replace('”-to-your-cart', '');
//console.log(res2);
	
window.location.href = "<?php echo site_url();?>/product/"+res2;	
	
});	
});	
</script>


<script>
jQuery(document).ready(function($){

jQuery(document).on('click', '.cus_colection_shop', function(){
localStorage.clear();
localStorage.setItem("shipping_opt", "collection");
window.location.href = "https://www.putneyshop.com/shop";

});

});	
</script>

<script>
jQuery(document).ready(function($){	
setTimeout(function(){
$('.woocommerce-shipping-totals .shipping-title').html('Shipping: ');
$('.woocommerce-shipping-totals.shipping th').html('Shipping: ');	
}, 3000);
	
var shipping_opt = localStorage.getItem("shipping_opt");
var zip_code_opt = localStorage.getItem("zip_code_opt");	
	
console.log(shipping_opt);
	
if(shipping_opt=='delivery'){
$('.single_add_to_cart_button').prop('disabled', false);
$('.shop_zip_check').hide();
	
$('#billing_postcode').val(zip_code_opt);	
$("select[name='coderockz_woo_delivery_delivery_selection_box'] option:eq(2)").attr("selected", false);	
$("select[name='coderockz_woo_delivery_delivery_selection_box'] option:eq(1)").attr("selected", "selected");
	
/*$('.header-main .container').prepend('<p class="cus_top_txt"><?php //echo get_field('top_header_text_after_put_available_zip_code', 1859);?> <span>'+zip_code_opt+'</span></p>');*/
	
} else if(shipping_opt=='collection'){
$('.single_add_to_cart_button').prop('disabled', false);
$('.shop_zip_check').hide();
	
//$('#billing_postcode').val('');	
$("select[name='coderockz_woo_delivery_delivery_selection_box'] option:eq(1)").attr("selected", false);		
$("select[name='coderockz_woo_delivery_delivery_selection_box'] option:eq(2)").attr("selected", "selected");
	
/*$('.header-main .container').prepend('<p class="cus_top_txt"><?php //echo get_field('top_header_text_after_select_collection', 1859);?></p>');*/
	
}else{
$('.single_add_to_cart_button').prop('disabled', true);
$('.shop_zip_check').show();
}

});	
</script>


<script>
jQuery(document).ready(function($){

jQuery(document).on('click', '#delivery_opn', function(){
$('#delivery').show();
$('#collection').hide();
	
	
});

});	
</script>

<script>
jQuery(document).ready(function($){
	
jQuery(document).on('click', '#collection_opn', function(){
$('#delivery').hide();
$('#collection').show();
	

	
//localStorage.clear();
//localStorage.setItem("shipping_opt", "collection");	
});	

});	
</script>


<script>
	jQuery(document).ready(function(){
		
var shipping_opt = localStorage.getItem("shipping_opt");
	
if(shipping_opt=='collection'){
	
}else{
	
		jQuery(document).on('change', '#billing_postcode', function(){

			var billing_postcode = jQuery(this).val();

			var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

			if( billing_postcode ){
            	jQuery.ajax({
	                url: ajaxurl,
	                type: "POST",
	                dataType: "text",
	                data: {
	                    //action name passing to function
	                    action:'add_the_product_to_cart_ajax',
	                    billing_postcode:billing_postcode,	                    
	                },
	                
	                success: function(data){                   
	                    //console.log(data);
	if(data=='success'){

		jQuery('.err_msg').hide();
		jQuery('#billing_postcode_field .suc_msg').hide();
        jQuery('#billing_postcode_field .suc_msg:first-child').show();
        jQuery('#billing_postcode_field').append("<span class='suc_msg' style='color:#69bf29;font-size:12px;font-style:italic;font-weight:700;margin-top:0px;'>Yoo Hoo! you are able to purchase products.</span>");   
	}else{
		jQuery('.suc_msg').hide();
		jQuery('#billing_postcode_field .err_msg').hide();
        jQuery('#billing_postcode_field .err_msg:first-child').show();
		jQuery('#billing_postcode_field').append("<span class='err_msg' style='color:#DD5246;font-size:12px;font-style:italic;font-weight:700;margin-top:0px;'>Delivery not available for this address. You can enter an alternative delivery address below or select 'Collection' (from our shop in Putney)</span>");  
	}   
	                    

	                }
	            });
            }

		});
	
}
		
	});
</script>

<!-- shipping postcode validation -->
<script>
	jQuery(document).ready(function(){
		
var shipping_opt = localStorage.getItem("shipping_opt");
	
if(shipping_opt=='collection'){
	
}else{	
	
		jQuery(document).on('change', '#shipping_postcode', function(){

			var shipping_postcode = jQuery(this).val();

			var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

			if( shipping_postcode ){
            	jQuery.ajax({
	                url: ajaxurl,
	                type: "POST",
	                dataType: "text",
	                data: {
	                    //action name passing to function
	                    action:'add_the_product_to_cart_ajax_new',
	                    shipping_postcode:shipping_postcode,	                    
	                },
	                
	                success: function(data){                   
	                    //console.log(data);
	if(data=='success'){

		jQuery('.err_msg').hide();
		jQuery('#shipping_postcode_field .suc_msg').hide();
        jQuery('#shipping_postcode_field .suc_msg:first-child').show();
        jQuery('#shipping_postcode_field').append("<span class='suc_msg' style='color:#69bf29;font-size:12px;font-style:italic;font-weight:700;margin-top:0px;'>Yoo Hoo! you are able to purchase products.</span>");   
	}else{
		jQuery('.suc_msg').hide();
		jQuery('#shipping_postcode_field .err_msg').hide();
        jQuery('#shipping_postcode_field .err_msg:first-child').show();
		jQuery('#shipping_postcode_field').append("<span class='err_msg' style='color:#DD5246;font-size:12px;font-style:italic;font-weight:700;margin-top:0px;'>Delivery is not available for the address you have given</span>");  
	}   
	                    

	                }
	            });
            }

		});
	
}
		
	});
</script>
<!-- ends -->

<script>
jQuery(document).ready(function($){
$('#dokan-store-listing-filter-form-wrap .store-lists-other-filter-wrap').prepend('<div class="categories-menu-title"><span class="title"><?php echo get_field('vendor_filter_section_heading', 1859);?></span></div>');
	
$('#dokan-store-listing-filter-form-wrap .category-box.store_category ul').prepend('<li data-slug="show-all">Show all</li>');	
	
jQuery(document).on('click', '#dokan-store-listing-filter-form-wrap .store_category li', function(e){
e.preventDefault();
	

	
$('#dokan-store-listing-filter-form-wrap .store_category li').removeClass('dokan-btn-theme');
$(this).addClass('dokan-btn-theme');

var data_slug = $(this).attr('data-slug');
	
if(data_slug=='show-all'){
location.replace("https://www.putneyshop.com/vendors/");   
}else{
location.replace("https://www.putneyshop.com/vendors/?store_categories[]="+data_slug);
//$('#apply-filter-btn').trigger('click');
	
}	

		});
	});
</script>

<script>
jQuery(document).ready(function($){
var img_src = $('.dokan-profile-frame-wrapper .profile-info-img').attr('src');	
$('.dokan-profile-frame-wrapper .profile-info-img').hide();
/*$('.dokan-profile-frame-wrapper .profile-info-box.profile-layout-default').css({"background":"url("+img_src+")", "background-repeat":"no-repeat", "background-position":"center center", "background-size":"cover"});*/

$('.dokan-single-store .profile-frame .profile-info-box .profile-info-summery-wrapper .profile-info-summery').css({"background-image":"url("+img_src+")", "background-repeat":"no-repeat", "background-position":"center center", "background-size":"cover"});
	
});
</script>	

<?php if($vendor_description!=''){?>

<script>
jQuery(document).ready(function($){
	
 /*$('<aside class="widget dokan-store-widget dokan-store-menu"><h3 class="widget-title">Vendor Details</h3><div id="cat-drop-stack" class="store-cat-stack-dokan"><?php //echo $vendor_description;?></div></aside>').insertAfter('.dokan-store-sidebar .dokan-widget-area aside:first-child');*/

 $('<div class="vendor_details"><h3 class="widget-title"><?php echo $dokan_store_name_new;?></h3><div id="cat-drop-stack" class="store-cat-stack-dokan"><?php echo $vendor_description;?></div></div>').insertAfter('.profile-frame .profile-info-summery');
	
	
});
</script>

<?php } ?>
	
<script>
jQuery(document).ready(function($){
	
$('<p class="billing_desc_cus">Please note: if you want delivery to a different address from your billing address then please enter the delivery address is the section \'Delivery to a different address\' below</p>').insertBefore('.woocommerce-billing-fields__field-wrapper');
	
$('<aside class="widget dokan-store-widget dokan-store-menu"><h3 class="widget-title">Vendor Details</h3><div id="cat-drop-stack" class="store-cat-stack-dokan"><p>To receive this vendor\'s products this weekend you must order before: <b style="text-transform:capitalize;"><?php echo $cutoff_day_ven.' '.$cutoff_time_ven;?></b></p></div></aside>').insertAfter('.dokan-store-sidebar .dokan-widget-area aside:first-child');
	
setTimeout(function(){ 
$('#coderockz_woo_delivery_delivery_selection_box_field label').each(function() {
    var text = $(this).html();
    $(this).html(text.replace('Order Type', 'Delivery or Collection (click to change)')); 
});	
}, 3000);	
	
setTimeout(function(){ 
$('#ce4wp_checkout_consent_checkbox_field label.checkbox').each(function() {
    var text = $(this).html();
    $(this).html(text.replace('Yes, I\'m ok with you sending me additional newsletter and email content', 'I agree for you to send me newsletters and email content')); 
});	
}, 3000);
	
	
});
</script>

<script>
jQuery(document).ready(function($){
	
//$('.woocommerce-checkout .showlogin').trigger('click');
$('.woocommerce-checkout .woocommerce-form-login.login p:first-child').html("It is necessary to be registered on our site to make a purchase. If you already have an account, please enter your details below. If you are a new customer, please <a href='https://www.putneyshop.com/my-account/' target='_blank'>REGISTER</a> now");	

});
</script>	

	</body>
</html>