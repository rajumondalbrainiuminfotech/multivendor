<?php
/**
 * Template Name: Vendor Listing Page
**/
?>
<?php get_header();?>

<div class="container-fluid">

  <div class="row">

<div class="col-md-3">
		
<div class="wpb_wrapper"><div class="kapee-element kapee-vertical-categories">
<div class="categories-menu-wrapper">
<div class="categories-menu-title">
<span class="title">Filter</span>
</div>
<div class="categories-menu kapee-navigation">
<ul id="menu-categories-menu" class="menu">
			
<li id="menu-item-1917" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-1917 item-level-0"><a href="https://www.putneyshop.com/product-category/fruits/" class="nav-link"><span>Fruits</span></a></li>

<li id="menu-item-1835" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1835 item-level-0"><a href="https://kapee.presslayouts.com/dummy/product-category/jewellery/" class="nav-link"><span>Artificial Jewellery</span></a>
</li>
	
</ul>
</div>	
</div>
</div>
</div>
	
</div>	
	  
	<div class="col-md-9">
    <div class="row">
		
<?php
$args = array(
    'role'    => 'seller',
    'orderby' => 'user_nicename',
    'order'   => 'ASC'
);
$users = get_users( $args );

foreach ( $users as $user ) {

$the_user_id = $user->ID;

$get_author_gravatar = get_avatar_url($the_user_id, array('size' => 130));

$args = array(
        'post_type'      => 'product',
        'posts_per_page' => 1,
        'author'    => $the_user_id
    );

$loop = new WP_Query( $args );

while ( $loop->have_posts() ) : $loop->the_post();
global $product;
$pro_image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );        
?>
	  
	
		
    <div class="col-sm-3">
    <a href="<?php echo site_url();?>/store/<?php echo esc_html( $user->user_nicename );?>">
    
    <div class="cus_user_img">
    <img src="<?php  echo $pro_image[0]; ?>" alt="<?php the_title();?>" style="height:200px; width:auto;" class="main_ven_prouct"><br>
    <img src="<?php  echo $get_author_gravatar; ?>" alt="<?php echo esc_html( $user->dokan_store_name );?>" class="vendor_avatar_img">
    </div>
		
    <div class="cus_user_details" style="clear:both;">
    <h4><?php echo esc_html( $user->dokan_store_name );?></h4>
    </div>
    
    </a>
    </div>
      
 
<?php endwhile; ?>   
<?php } ?>    
<?php wp_reset_query();?>   
</div>
		</div>
	  
  </div>
</div>
 
 
<?php get_footer();?>