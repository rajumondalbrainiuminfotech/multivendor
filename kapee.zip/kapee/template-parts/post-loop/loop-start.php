<?php
/**
 * Post Loop Start
 *
 * @author 	PressLayouts
 * @package kapee/template-parts/post-loop
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="<?php kapee_blog_wrapper_classes();?>">


